First off, Thank you for buying <3
I am happy that someone found this interesting enough for them to buy it and I hope you get to use it for an or many interesting project(s).

The .zip folder you've recieve contains a complete sheet of all the assets in both .png and .pdn as well as .gifs cycle through all the frames of all the characters.
In addition you can also find 2 .ase files which have the sprites in layers so you potentially could make your own, however as stated on the asset page, Aseprite costs money, but the demo can be used for copypasting the assets.
There is also 4 other files, one of which is the logo from the itch.io page in 1:1, 2 others which are examples and the last one which is the original doodle, this was all based on.

Lastly I'd like to add that if you want to give feedback or have any requests, you can contact me by email at scissormarks@gmail.com and through twitter @scissormarks.

Thanks again and I hope you like it.

PS. If you release something with these assets, I would be happy if you'd give a little credit and link to my page. :)